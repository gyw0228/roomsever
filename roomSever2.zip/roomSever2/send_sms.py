﻿# -*- coding:utf-8 -*-
import requests
import json

def send_common_sms(phone, code):
    req_url = "http://api.feige.ee/SmsService/Send"
    data = {"Account": "", "Pwd": "", "Content": "验证码:" + code,
            "Mobile": phone, "SignId":"123"  }

    response = requests.post(req_url, data=data)

    return json.loads(response.content)

# if __name__ == "__main__":
#     #send_template_sms("13012345678", "1234")