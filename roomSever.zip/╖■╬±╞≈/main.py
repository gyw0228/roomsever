import threading

from flask import Flask, request, jsonify, redirect, render_template, session as http_session, send_from_directory

from sqlalchemy import Column, String, create_engine, Integer
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import time, datetime
from threading import Thread
import json
import random
from send_sms import *

import os

Base = declarative_base()


class Room(Base):
    """
    标识一个房间
    """
    __tablename__ = "t_room"

    id = Column(Integer, name="id", primary_key=True, autoincrement=True, nullable=True)
    rtwo1_up = Column(name="rtwo1_up")
    rtwo_down = Column(name="rtwo1_down")

    rtwo2_up = Column(name="rtwo2_up")
    rtwo2_down = Column(name="rtwo2_down")

    rtwo3_up = Column(name="rtwo3_up")
    rtwo3_down = Column(name="rtwo3_down")

    rfour_up = Column(name="rfour_up")
    rfour_down = Column(name="rfour_down")

    rsix_up = Column(name="rsix_up")
    rsix_down = Column(name="rsix_down")

    reight_up = Column(name="reight_up")
    reight_down = Column(name="reight_down")

    rtwelve_up = Column(name="rtwelve_up")
    rtwelve_down = Column(name="rtwelve_down")


class Student(Base):
    """
    标识一个学生选定的房间
    """
    __tablename__ = "t_student"

    id = Column(Integer, name="id", primary_key=True, autoincrement=True, nullable=True)
    name = Column(name="name")
    gender = Column(name="gender")
    telephone = Column(name="telephone")
    start_date = Column(name="start_date")
    end_date = Column(name="end_date")
    vx_id = Column(name="vx_id")
    room_type = Column(name="room_type")
    deleted = Column(Integer, name="deleted")


class RoomEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Room):
            return {
                "id": o.id,
                "rtwo1_up": o.rtwo1_up,
                "rtwo1_down": o.rtwo1_down,
                "rtwo2_up": o.rtwo2_up,
                "rtwo2_down": o.rtwo2_down,
                "rtwo3_up": o.rtwo3_up,
                "rtwo3_down": o.rtwo3_down,
                "rfour_up": o.rfour_up,
                "rfour_down": o.rfour_down,
                "rsix_up": o.rsix_up,
                "rsix_down": o.rsix_down,
                "reight_up": o.reight_up,
                "reight_down": o.reight_down,
                "rtwelve_up": o.rtwelve_up,
                "rtwelve_down": o.rtwelve_down
            }
        return json.JSONEncoder.default(self, o)


engine = create_engine("mysql+mysqlconnector://root:root@localhost:3306/setroom", pool_recycle=3600)
DBSession = sessionmaker(bind=engine)

app = Flask(__name__)

app.config['SECRET_KEY'] = "123456"


@app.route("/a/download_data")
def download_data():
    """
    下载数据
    :return:
    """
    session = DBSession()
    student_list = session.query(Student).filter(Student.deleted == 0)
    with open("./student.csv", "w", encoding="gbk") as f:
        f.write("编号, 姓名, 性别, 电话, 入住日期, 退房日期, 房间类型, 铺位类型\n")
        for x in student_list:
            f.write(str(
                x.id) + "," + x.name + "," + x.gender + "," + x.telephone + "," + x.start_date + "," + x.end_date + "," + map_room_type(
                x.room_type) + "," + map_room_type2(x.room_type) + "\n")
    return send_from_directory(directory=os.getcwd(), filename="student.csv", cache_timeout=0)
    # return send_from_directory(directory=os.getcwd(), filename="student.csv", path=os.getcwd(), cache_timeout=0)


@app.route("/a/setroom", methods=["POST"])
def setroom():
    """
    设置房间数量
    :return:
    """
    rtwo1_up = int(request.form['rtwo1_up'])
    rtwo1_down = int(request.form['rtwo1_down'])

    rtwo2_up = int(request.form['rtwo2_up'])
    rtwo2_down = int(request.form['rtwo2_down'])

    rtwo3_up = int(request.form['rtwo3_up'])
    rtwo3_down = int(request.form['rtwo3_down'])

    rfour_up = int(request.form['rfour_up'])
    rfour_down = int(request.form['rfour_down'])

    rsix_up = int(request.form['rsix_up'])
    rsix_down = int(request.form['rsix_down'])

    reight_up = int(request.form['reight_up'])
    reight_down = int(request.form['reight_down'])

    rtwelve_up = int(request.form['rtwelve_up'])
    rtwelve_down = int(request.form['rtwelve_down'])

    if rtwo1_up <= 0 or rtwo1_down <= 0  or rtwo1_up <= 0 \
            or rtwo2_down <= 0 or rtwo2_up <= 0 or rtwo2_down <= 0\
            or rtwo3_up <= 0 or rtwo3_down <= 0 \
            or rfour_up <= 0 or rfour_down <= 0 \
            or rsix_up <= 0 or rsix_down <= 0 \
            or rtwelve_up <= 0 or rtwelve_down <= 0 \
            or reight_up <= 0 or reight_down <= 0:
        return redirect("/a/room", code=302)

    room = Room(rtwo1_up=rtwo1_up, rtwo1_down=rtwo1_down,
                rtwo2_up=rtwo2_up, rtwo2_down=rtwo2_down,
                rtwo3_up=rtwo3_up, rtwo3_down=rtwo3_down,
                rsix_up=rsix_up, rtwo_down=rsix_down,
                rtwelve_up=rtwelve_up, rtwelve_down=rtwelve_down,
                rfour_up=rfour_up, rfour_down=rfour_down, reight_up=reight_up,
                reight_down=reight_down)

    session = DBSession()

    # 查询是否存在
    all = session.query(Room).filter(Room.id == 1).all()
    if len(all) > 0:  # 更新
        session.query(Room).filter(Room.id == 1).update({
            Room.rtwo1_up: request.form['rtwo1_up'],
            Room.rtwo1_down: request.form['rtwo1_down'],
            Room.rtwo2_up: request.form['rtwo2_up'],
            Room.rtwo2_down: request.form['rtwo2_down'],
            Room.rtwo3_up: request.form['rtwo3_up'],
            Room.rtwo3_down: request.form['rtwo3_down'],
            Room.rfour_up: request.form['rfour_up'],
            Room.rfour_down: request.form['rfour_down'],
            Room.rsix_up: request.form['rsix_up'],
            Room.rsix_down: request.form['rsix_down'],
            Room.reight_up: request.form['reight_up'],
            Room.reight_down: request.form['reight_down'],
            Room.rtwelve_up: request.form['rtwelve_up'],
            Room.rtwelve_down: request.form['rtwelve_down']
        })
    else:
        room.id = 1
        session.add(room)

    session.commit()
    session.close()

    return redirect("/a/room", code=302)


@app.route("/a/room")
def index():
    """
    设置
    :return:
    """
    session = DBSession()
    room = session.query(Room).filter(Room.id == 1).all()

    if len(room) > 0:
        return render_template("/setroom.html", room=room[0])
    else:
        return render_template("/setroom.html", room={
            "rtwo1_up": 0,
            "rtwo1_down": 0,
            "rtwo2_up": 0,
            "rtwo2_down": 0,
            "rtwo3_up": 0,
            "rtwo3_down": 0,
            "rfour_up": 0,
            "rfour_down": 0,
            "rsix_up": 0,
            "rsix_down": 0,
            "reight_up": 0,
            "reight_down": 0,
            "rtwelve_up": 0,
            "rtwelve_down": 0
        })


@app.route("/isbind", methods=["POST"])
def isbind():
    """
    判断这个微信号是否已经选择
    :return:
    """
    session = DBSession()
    id = request.form['openId']
    data = session.query(Student).filter(Student.vx_id == id, Student.deleted == 0).all()

    if len(data) > 0:
        s = data[0]
        return jsonify({
            "result": True,
            "data": {
                "name": s.name,
                "gender": s.gender,
                "telephone": s.telephone,
                "start_date": s.start_date,
                "end_date": s.end_date,
                "room_type": s.room_type
            }
        })
    else:
        return jsonify({
            "result": False
        })


lock = threading.Lock()


@app.route("/inroom", methods=["POST"])
def inroom():
    """
    入住
    :return:
    """
    lock.acquire(blocking=True)

    try:
        vx_id = request.form['vx_id']

        if vx_id is None:
            return "ERROR"

        session = DBSession()
        if len(session.query(Student).filter(Student.vx_id == vx_id, Student.deleted == 0).all()) == 0:
            name = request.form['name']
            gender = request.form['gender']
            telephone = request.form['telephone']
            start_date = request.form['start_date']
            end_date = request.form['end_date']

            room_type = request.form['room_type']

            # 判断房间类型是否还有空余
            if room_type == "rtwo1_up" or room_type == "rwo1_down" \
                    or room_type == "rtwo2_up" or room_type == "rtwo2_down" \
                    or room_type == "rtwo3_up" or room_type == "rtwo3_down" \
                    or room_type == "rfour_up" or room_type == "rfour_down" \
                    or room_type == "rsix_up" or room_type == "rsix_down" \
                    or room_type == "reight_up" or room_type == "reight_down"\
                    or room_type == "rtwelve_up" or room_type == "rtwelve_down" :

                r = session.query(Room).filter(Room.id == 1).all()[0]
                data = session.execute((
                        "select count(*) as room_count from t_student where deleted = 0 and room_type = '%s'" % (
                    room_type))).fetchall()
                count = json.loads(json.dumps(r, cls=RoomEncoder))[room_type]

                if data[0][0] >= count:
                    return jsonify({
                        "status": 400,
                        "data": ""
                    })
                else:
                    student = Student(id=None, name=name, gender=gender, telephone=telephone, start_date=start_date
                                      , end_date=end_date, vx_id=vx_id, room_type=room_type, deleted=0)

                    session.add(student)

        session.commit()
        session.close()

        lock.release()

        return jsonify({
            "status": 200,
            "data": ""
        })
    except:
        lock.release()

        return jsonify({
            "status": 400,
            "data": ""
        })


@app.route("/getnum")
def getnum():
    """
    房间数
    :return:
    """
    session = DBSession()

    data = session.execute(
        "select room_type, count(room_type) as room_count from t_student where deleted = 0 group by room_type").fetchall()
    r = session.query(Room).filter(Room.id == 1).all()[0]

    # (上铺数量 + 下铺数量) - (已订上铺数量 + 已订下铺数量)
    s = {}
    for x in data:
        s.setdefault(x[0], x[1])
    if "rtwo1_up" not in s: s.setdefault("rtwo1_up", 0)
    if "rtwo1_down" not in s: s.setdefault("rtwo1_down", 0)
    if "rtwo2_up" not in s: s.setdefault("rtwo2_up", 0)
    if "rtwo2_down" not in s: s.setdefault("rtwo2_down", 0)
    if "rtwo3_up" not in s: s.setdefault("rtwo3_up", 0)
    if "rtwo3_down" not in s: s.setdefault("rtwo3_down", 0)
    if "rfour_up" not in s: s.setdefault("rfour_up", 0)
    if "rfour_down" not in s: s.setdefault("rfour_down", 0)
    if "rsix_up" not in s: s.setdefault("rsix_up", 0)
    if "rsix_down" not in s: s.setdefault("rsix_down", 0)
    if "reight_up" not in s: s.setdefault("reight_up", 0)
    if "reight_down" not in s: s.setdefault("reight_down", 0)
    if "rtwelve_up" not in s: s.setdefault("rtwelve_up", 0)
    if "rtwelve_down" not in s: s.setdefault("rtwelve_down", 0)

    # 二人间(无独卫)
    rtwo1_count = (r.rtwo1_up + r.rtwo1_down) - (s['rtwo1_up'] + s['rtwo1_down'])
    rtwo1_up = r.rtwo1_up - s['rtwo1_up']
    rtwo1_down = r.rtwo1_down - s['rtwo1_down']

    # 二人间（内窗）
    rtwo2_count = (r.rtwo2_up + r.rtwo2_down) - (s['rtwo2_up'] + s['rtwo2_down'])
    rtwo2_up = r.rtwo2_up - s['rtwo2_up']
    rtwo2_down = r.rtwo2_down - s['rtwo2_down']

    # 二人间（标准）
    rtwo3_count = (r.rtwo3_up + r.rtwo3_down) - (s['rtwo3_up'] + s['rtwo3_down'])
    rtwo3_up = r.rtwo3_up - s['rtwo3_up']
    rtwo3_down = r.rtwo3_down - s['rtwo3_down']

    # 四人间
    rfour_count = (r.rfour_up + r.rfour_down) - (s['rfour_up'] + s['rfour_down'])
    rfour_up = r.rfour_up - s['rfour_up']
    rfour_down = r.rfour_down - s['rfour_down']

    # 六人间
    rsix_count = (r.rsix_up + r.rsix_down) - (s['rsix_up'] + s['rsix_down'])
    rsix_up = r.rsix_up - s['rsix_up']
    rsix_down = r.rsix_down - s['rsix_down']

    # 八人间
    reight_count = (r.reight_up + r.reight_down) - (s['reight_up'] + s['reight_down'])
    reight_up = r.reight_up - s['reight_up']
    reight_down = r.reight_down - s['reight_down']

    # 十二人间
    rtwelve_count = (r.rtwelve_up + r.rtwelve_down) - (s['rtwelve_up'] + s['rtwelve_down'])
    rtwelve_up = r.rtwelve_up - s['rtwelve_up']
    rtwelve_down = r.rtwelve_down - s['rtwelve_down']

    return jsonify({
        "rtwo1": [rtwo1_count, rtwo1_up, rtwo1_down],
        "rtwo2": [rtwo2_count, rtwo2_up, rtwo2_down],
        "rtwo3": [rtwo3_count, rtwo3_up, rtwo3_down],
        "rfour": [rfour_count, rfour_up, rfour_down],
        "rsix": [rsix_count, rsix_up, rsix_down],
        "reight": [reight_count, reight_up, reight_down],
        "rtwelve": [rtwelve_count, rtwelve_up, rtwelve_down]
    })


def checkout():
    """
    退房
    :return:
    """
    while True:
        print(str(datetime.datetime.now()) + " 执行退房")
        session = DBSession()
        student_list = session.query(Student).filter(Student.deleted == 0).all()
        for student in student_list:
            timeArray = time.strptime(student.end_date, "%Y-%m-%d")
            timeStamp = int(time.mktime(timeArray))
            if datetime.datetime.now().timestamp() > timeStamp:  # 退房
                session.query(Student).filter(Student.id == Student.id).update({
                    "deleted": 1
                })
        session.commit()
        session.close()

        time.sleep(24 * 60 * 60)


@app.route("/web/get_check_code", methods=["POST"])
def get_check_code():
    """
    网页接口 获取手机号验证码
    :return:
    """
    telephone = request.form['telephone']

    session = DBSession()
    data = session.query(Student).filter(Student.telephone == telephone, Student.deleted == 0).all()

    if len(data) > 0:
        s = data[0]
        return jsonify({
            "result": True,
            "data": {
                "name": s.name,
                "gender": s.gender,
                "telephone": s.telephone,
                "start_date": s.start_date,
                "end_date": s.end_date,
                "room_type": s.room_type
            }
        })
    else:  # 发送验证码
        code = str(random.randint(1000, 10000) * 3)
        if send_common_sms(telephone, code)['SuccessCount'] != 1:
            return jsonify({
                "result": True,
            })
        else:
            http_session.setdefault("code", code)
            return jsonify({
                "result": False,
            })


@app.route("/web/inroom_by_web", methods=["POST"])
def inroom_by_web():
    # 校验
    start_date = request.form['start_date']
    end_date = request.form['end_date']
    timeArray = time.strptime(start_date, "%Y-%m-%d")
    start_timeStamp = int(time.mktime(timeArray))

    timeArray = time.strptime(end_date, "%Y-%m-%d")
    end_timeStamp = int(time.mktime(timeArray))

    if end_timeStamp <= start_timeStamp:
        return "<head><meta name='viewport' content='width=device-width, initial-scale=1.0'></head><a href='/static/web_setroom.html'>没有申请入住请点击这里</a>错误的日期选择"

    # checkcode = request.form['checkcode']
    # if http_session.get("code") is None:
    #     return "<head><meta name='viewport' content='width=device-width, initial-scale=1.0'></head><a href='/static/web_setroom.html'>没有申请入住请点击这里</a>请获取验证码"
    #
    # if checkcode != http_session.get("code"):
    #     http_session.pop("code")
    #     return "<head><meta name='viewport' content='width=device-width, initial-scale=1.0'></head><a href='/static/web_setroom.html'>没有申请入住请点击这里</a>验证码错误，请重新获取"

    telephone = request.form['telephone']

    session = DBSession()
    data = session.query(Student).filter(Student.telephone == telephone, Student.deleted == 0).all()

    if len(data) > 0:
        s = data[0]

        return render_template("/web_selected.html", data={
            "name": s.name,
            "gender": s.gender,
            "telephone": s.telephone,
            "start_date": s.start_date,
            "end_date": s.end_date,
            "room_type": map_room_type(s.room_type)
        })
    else:
        name = request.form['name']
        gender = request.form['gender']
        telephone = request.form['telephone']
        start_date = request.form['start_date']
        end_date = request.form['end_date']

        room_type = request.form['room_type'] + "_" + request.form['room_type2']
        if map_room_type(room_type) is None:
            return "<head><meta name='viewport' content='width=device-width, initial-scale=1.0'></head><a href='/static/web_setroom.html'>没有申请入住请点击这里</a>房间类型错误"

        # 判断房间类型是否还有空余
        if room_type == "rtwo1_up" or room_type == "rwo1_down" \
                or room_type == "rtwo2_up" or room_type == "rtwo2_down" \
                or room_type == "rtwo3_up" or room_type == "rtwo3_down" \
                or room_type == "rfour_up" or room_type == "rfour_down" \
                or room_type == "rsix_up" or room_type == "rsix_down" \
                or room_type == "reight_up" or room_type == "reight_down"\
                or room_type == "rtwelve_up" or room_type == "rtwelve_down" :

            r = session.query(Room).filter(Room.id == 1).all()[0]
            data = session.execute(
                ("select count(*) as room_count from t_student where deleted = 0 and room_type = '%s'" % (
                    room_type))).fetchall()
            count = json.loads(json.dumps(r, cls=RoomEncoder))[room_type]

            if data[0][0] >= count:
                return jsonify({
                    "result": True,
                    "status": 400,
                    "data": ""
                })
            else:
                student = Student(id=None, name=name, gender=gender, telephone=telephone, start_date=start_date
                                  , end_date=end_date, vx_id="0", room_type=room_type, deleted=0)

                session.add(student)
        else:
            return "<head><meta name='viewport' content='width=device-width, initial-scale=1.0'></head><a href='/static/web_setroom.html'>没有申请入住请点击这里</a>该类型房间已经订满"

        session.commit()
        session.close()
    return render_template("/web_selected.html", data={
        "name": name,
        "gender": gender,
        "telephone": telephone,
        "start_date": start_date,
        "end_date": end_date,
        "room_type": map_room_type(room_type)
    })


@app.route("/web/find_by_telephone")
def find_by_telephone():
    telephone = request.args['telephone']

    session = DBSession()
    data = session.query(Student).filter(Student.telephone == telephone, Student.deleted == 0).all()

    if len(data) > 0:
        s = data[0]

        return render_template("/web_selected.html", data={
            "name": s.name,
            "gender": s.gender,
            "telephone": s.telephone,
            "start_date": s.start_date,
            "end_date": s.end_date,
            "room_type": map_room_type(s.room_type)
        })
    else:
        return "<head><meta name='viewport' content='width=device-width, initial-scale=1.0'></head><a href='/static/web_setroom.html'>没有申请入住请点击这里</a>";


@app.route("/")
def web_index():
    return redirect("/static/find.html", code=302)


def map_room_type(room_type):
    if room_type == "rtwo1_up":
        return "二人间(无独卫)"
    elif room_type == "rtwo1_down":
        return "二人间(无独卫)"
    elif room_type == "rtwo2_up":
        return "二人间(内窗)"
    elif room_type == "rtwo2_down":
        return "二人间(内窗)"
    elif room_type == "rtwo3_up":
        return "二人间(标准)"
    elif room_type == "rtwo3_down":
        return "二人间(标准)"
    elif room_type == "rfour_up":
        return "四人间"
    elif room_type == "rfour_down":
        return "四人间"
    elif room_type == "rsix_up":
        return "六人间"
    elif room_type == "rsix_down":
        return "六人间"
    elif room_type == "reight_up":
        return "八人间",
    elif room_type == "reight_down":
        return "八人间"
    elif room_type == "rtwelve_up":
        return "十二人间"
    elif room_type == "rtwelve_down":
        return "十二人间"
    else:
        return None


def map_room_type2(room_type):
    if room_type == "rtwo1_up":
        return "上铺"
    elif room_type == "rtwo1_down":
        return "下铺"
    elif room_type == "rtwo2_up":
        return "上铺"
    elif room_type == "rtwo2_down":
        return "下铺"
    elif room_type == "rtwo3_up":
        return "上铺"
    elif room_type == "rtwo3_down":
        return "下铺"
    elif room_type == "rfour_up":
        return "上铺"
    elif room_type == "rfour_down":
        return "下铺"
    elif room_type == "rsix_up":
        return "上铺"
    elif room_type == "rsix_down":
        return "下铺"
    elif room_type == "reight_up":
        return "上铺",
    elif room_type == "reight_down":
        return "下铺"
    elif room_type == "rtwelve_up":
        return "上铺"
    elif room_type == "rtwelve_down":
        return "下铺"
    else:
        return None


if __name__ == "__main__":
    t = Thread(target=checkout)
    t.start()

    app.run(host="127.0.0.1", port=5002)
